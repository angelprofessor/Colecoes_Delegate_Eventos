﻿using System;
namespace DE3
{
    delegate int DelegadoParaComposicaoFunc(int X);
    public class ContentorDeFunc
    {
        public static int Dobro(int X)
        { return X * 2; }
        public static int Triplo(int X)
        { return X * 3; }
    }
    public class ComposicaoDeFuncoes
    {
        static void Main(string[] args)
        {
            DelegadoParaComposicaoFunc[] D ={
                ContentorDeFunc.Triplo,
                ContentorDeFunc.Dobro};
            int X = 5;
            Console.WriteLine("Triplo do dobro de {0}={1}", X,
            D[0](D[1](X))
            );
        }
    }
}