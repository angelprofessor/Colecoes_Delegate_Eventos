﻿using System;
using System.Collections;
namespace CC8
{
    public class Iterando
    {
        public static void Main()
        {
            ArrayList Frutos = new ArrayList();
            Frutos.Add("Laranjas");
            Frutos.Add("Papaia");
            Frutos.Add("Manga");
            Frutos.Add("Morangos");
            IEnumerator Item = Frutos.GetEnumerator();
            Item.MoveNext();
            for (int i = 0; i <= Frutos.Count - 1; i++)
            {
                Console.WriteLine(Item.Current.ToString());
                Item.MoveNext();
            }
        }
    }
}
