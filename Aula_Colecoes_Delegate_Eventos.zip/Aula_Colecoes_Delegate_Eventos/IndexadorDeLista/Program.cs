﻿using System;
namespace CC2
{
    public class MaterialEscolar
    {
        private string NomeDonoDoMaterial;
        private string[] Material;
        private int Ultindice = 0;
        public MaterialEscolar(string N, params string[] Descricao)
        {
            NomeDonoDoMaterial = N;
            Material = new string[10];
            foreach (string M in Descricao) Material[Ultindice++] = M;
        }
        public string PNome
        {
            get
            { return NomeDonoDoMaterial; }
        }
        public int PIndice
        {
            get
            { return Ultindice; }
        }
        public string this[int I]
        {
            get
            {
                try
                { 
                    return Material[I]; 
                }
                catch
                {
                    return "Erro! Índice menor que zero ou maior do que a capacidade máxima da lista"; 
                }
            }
            set
            {
                try
                {
                    Material[I] = value;
                    if (Ultindice < I + 1) Ultindice = I;
                }
                catch
                {
                    Console.WriteLine("Erro! A capacidade da lista foiultrapassada");
                }
            }
        }
    }
    public class ListaDeMaterialEscolar
    {
        static void Main(string[] args)
        {
            MaterialEscolar ME = new MaterialEscolar("Inês", "Caneta","Lápis");
            ME[2] = "Caderno";
            ME[3] = "Borracha";
            ME[4] = "Afiador";
            ME[6] = "Livro";
            Console.WriteLine("Material para {0}", ME.PNome);
            for (int I = 0; I <= ME.PIndice; I++)
            { Console.WriteLine("{0}-{1}", I + 1, ME[I]); }
            Console.WriteLine(ME[11]);
        }
    }
}