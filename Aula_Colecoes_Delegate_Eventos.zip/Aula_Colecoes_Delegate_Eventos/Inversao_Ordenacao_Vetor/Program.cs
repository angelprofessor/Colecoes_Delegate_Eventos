﻿using System;
namespace CC1
{
    public class MaisMetodosParaArrays
    {
        public static void ImprimirVectorOrd(
            int[] Numeros, 
            string ordem)
        {
            Console.WriteLine(ordem);
            foreach (int I in Numeros)
            { Console.Write("{0} ", I); }
            Console.WriteLine();
        }
    }
    public class Ordenacoes
    {
        static void Main(string[] args)
        {
            int[] Numeros = { 1, 12, 5, 6, 7, 2, 3, 10, 9, 11 };
            Array.Sort(Numeros);
            MaisMetodosParaArrays.ImprimirVectorOrd(Numeros, "Númerospor ordem crescente");
            Array.Reverse(Numeros);
            MaisMetodosParaArrays.ImprimirVectorOrd(Numeros, "Númerospor ordem inversa");
        }
    }
}
