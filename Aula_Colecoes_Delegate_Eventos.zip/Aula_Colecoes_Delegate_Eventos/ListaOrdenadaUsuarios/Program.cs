﻿using System;
using System.Collections;

namespace CC3
{
    public class ListaOrdenada
    {
        public static void Main()
        {
            ArrayList Usuarios = new ArrayList();

            //PARA CASO QUEIRA TESTAR A ENTRADA PELO USUARIO
            //Console.Write("Nome do Usuario <ZZZ para terminar> ");            
            //string nome = Console.ReadLine();
            // while (nome.ToUpper().CompareTo("ZZZ") != 0)
            // {
            //Usuarios.Add(nome);
            //Console.Write("Nome do Usuario <ZZZ para terminar> ");
            //nome = Console.ReadLine();
            // }
            string[] Nomes = { "Carla", "Rui", "Rosa", "Abel", "Maria", "ZZZ" };
            foreach (string n in Nomes)
            {
                Usuarios.Add(n);
            }
            Usuarios.Sort();
            Console.WriteLine("Lista de Usuarios:");
            foreach (string Ele in Usuarios) Console.WriteLine("{0}", Ele);
        }
    }
}
