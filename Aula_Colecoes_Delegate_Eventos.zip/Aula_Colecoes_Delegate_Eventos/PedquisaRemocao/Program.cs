﻿using System;
using System.Collections;

namespace CC6
{
    public class PesqElimina
    {
        public static void Main()
        {
            string[] Localid = { "Porto", "Lisboa", "Braga", "Vila Real","Faro", "Coimbra" };
            ArrayList Localidade = new ArrayList();
            foreach (string Ele in Localid)
                Localidade.Add(Ele);
            Localidade.Sort();
            Console.Write("Digite o nome da localidade a eliminar ");
            string X = "Braga";//Console.ReadLine();
            if (Localidade.BinarySearch(X) >= 0)
                Localidade.Remove(X);
            else
                Console.WriteLine("{0} não existe no conjunto", X);
            foreach (string Ele in Localidade)
                Console.WriteLine(Ele);
        }
    }
}
