﻿using System;
using System.Collections;
namespace CC4
{
    public class SubListaDeNomes
    {
        public static void Main()
        {
            ArrayList Usuarios = new ArrayList();
            //Console.Write("Nome do Usuario <ZZZ para terminar> ");
            //string nome = Console.ReadLine().ToUpper();
            //while (nome.CompareTo("ZZZ") != 0)
            //{
            //    Usuarios.Add(nome);
            //    Console.Write("Nome do Usuario <ZZZ para terminar> ");
            //    nome = Console.ReadLine().ToUpper();
            //}

            string[] Nomes = { "Carla", "Rui", "Beatriz","Rosa", "Calorina", "Beto","Abel", "Maria", "Dília", "ZZZ" };
            foreach (string n in Nomes)
            {
                Usuarios.Add(n.ToUpper());
            }

            Usuarios.Sort();
            int Inicio, Fim;
            try
            {
                Inicio = Usuarios.IndexOf("BEATRIZ", 0);
                Fim = Usuarios.IndexOf("DÍLIA", 0);
                Console.WriteLine("Sublista de nomes");
                foreach (string Ele in Usuarios.GetRange(Inicio, Fim - Inicio + 1))
                    Console.WriteLine(Ele);
            }
            catch
            { Console.WriteLine("Vazia ou não contém BEATRIZ ou DÍLIA"); }
        }
    }
}
