﻿using System;
namespace DE1
{
    delegate int DelegadoParaExecFuncoes(int X);
    public class RestosDivisao
    {
        public static int Dois(int X)
        { return X % 2; }
        public static int Tres(int X)
        { return X % 3; }
    }
    public class RestosPorDoisETres
    {
        static void Main(string[] args)
        {
            DelegadoParaExecFuncoes D;
            int X = 4;
            D = new DelegadoParaExecFuncoes(RestosDivisao.Dois);
            Console.WriteLine("Resto de {0} a dividir por 2={1}", X, D(X));
            D = new DelegadoParaExecFuncoes(RestosDivisao.Tres);
            Console.WriteLine("Resto de {0} a dividir por 3 ={ 1} ",X,D(X));                
        }
    }
}
