﻿using System;
namespace DE6
{
    delegate void DelegadoParaLinhas
        (
            ref string Cadeia, 
            string Caract
        );
    public class Contentor
    {
        public static void CadeiaCaract(ref string Cadeia, string Caract)
        { Cadeia += Caract; Console.WriteLine(Cadeia); }
    }
    public class TrianguloPorDelegado
    {
        static void Main(string[] args)
        {
            DelegadoParaLinhas LinhasD;
            int NLinhas = 10;
            LinhasD = new DelegadoParaLinhas(Contentor.CadeiaCaract);
            for (int I = 1; I < NLinhas; I++)
                LinhasD += new DelegadoParaLinhas(Contentor.CadeiaCaract);
            string Linha = "";
            LinhasD(ref Linha, "a");
        }
    }
}