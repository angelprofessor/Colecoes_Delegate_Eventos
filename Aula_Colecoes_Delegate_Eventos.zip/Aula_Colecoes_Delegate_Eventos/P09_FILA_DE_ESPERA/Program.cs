﻿using System;
using System.Collections;
namespace CC9
{
    public class PessoasEmFila
    {
        public static void ColocarNaFila(Queue Q)
        {
            string Nome;

            //PARA TESTAR ENTRADA PELO USUARIO
            //Console.Write("Digite o nome da pessoa (ZZZ para terminar)");
            //Nome = Console.ReadLine();
            //while (Nome.ToUpper() != "ZZZ")
            //{
            //    Q.Enqueue(Nome);
            //    Console.Write("Digite o nome da pessoa (ZZZ paraterminar)");
            //    Nome = Console.ReadLine();
            //}

            string[] Nomes = { "Carla", "Rui", "Beatriz", "Rosa", "Calorina", "Beto", "Abel", "Maria", "Dília", "ZZZ" };
            for (int i = 0; i < Nomes.Length; i++)
            {
                Nome = Nomes[i].ToUpper();
                Q.Enqueue(Nome);
            }
        }
        public static void ImprimirFila(Queue Q)
        {
            Console.WriteLine("Estado da fila");
            IEnumerator Ele = Q.GetEnumerator();
            while (Ele.MoveNext())
            { Console.WriteLine(Ele.Current); }
            Console.WriteLine("Estão na fila {0} pessoas", Q.Count);
        }
        public static void Main(string[] args)
        {
            Queue Q = new Queue();
            ColocarNaFila(Q);
            ImprimirFila(Q);
        }
    }
}