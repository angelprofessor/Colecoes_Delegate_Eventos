﻿using System;
namespace DE8
{
    public class ParDeObjectos
    {
        private object[] OPar = new object[2];
        public delegate int Ordenar(object O1, object O2);
        public ParDeObjectos(object O1, object O2)
        {
            OPar[0] = O1;
            OPar[1] = O2;
        }
        public void Ordem(Ordenar FuncaoDel)
        {
            if (FuncaoDel(OPar[0], OPar[1]) == 2)
            {
                object Temporaria = OPar[0];
                OPar[0] = OPar[1]; OPar[1] = Temporaria;
            }
        }
        public override string ToString()
        { return OPar[0].ToString() + " e " + OPar[1].ToString(); }
    }
    public class Gato
    {
        private int Peso;
        public Gato(int P)
        { Peso = P; }
        public static int OrdemPesos(Object O1, object O2)
        {
            Gato G1 = (Gato)O1;
            Gato G2 = (Gato)O2;
            return (G1.Peso < G2.Peso ? 1 : 2);
        }
        public override string ToString()
        { return Peso.ToString() + "kg"; }
    }
    public class OrdenarPesos
    {
        static void Main(string[] args)
        {
            Gato G1 = new Gato(20);
            Gato G2 = new Gato(15);
            ParDeObjectos Pares = new ParDeObjectos(G1, G2);
            ParDeObjectos.Ordenar Delegado = new
            ParDeObjectos.Ordenar(Gato.OrdemPesos);
            Pares.Ordem(Delegado);
            Console.WriteLine(Pares.ToString());
        }
    }
}