﻿using System;
namespace DE12
{
    public class InfHoras : EventArgs
    {
        public int Hora;
        public int Minuto;
        public int Segundo;
        public string Ciclos;
        public InfHoras(int H, int M, int S, int C)
        {
            Hora = H;
            Minuto = M;
            Segundo = S;
            Ciclos = " Ciclos " + C;
        }
    }
    public class Relogio
    {
        private int Hora;
        private int Minuto;
        private int Segundo;
        public delegate void IncrementacaoSeg(object Relogio, InfHoras T);
        public event IncrementacaoSeg UmSegMais;
        public void Run()
        {
            int Ciclos = 0;
            while (Ciclos <= 90000000)
            {
                System.DateTime Agora = System.DateTime.Now;
                if (Agora.Second != this.Segundo)
                {
                    InfHoras T = new InfHoras(Agora.Hour, Agora.Minute,
                   Agora.Second, Ciclos);
                    UmSegMais(this, T);
                }
                this.Segundo = Agora.Second;
                this.Minuto = Agora.Minute;
                this.Hora = Agora.Hour;
                Ciclos++;
            }
        }
    }
    public class Consumidor1
    {
        public void Subscricao(Relogio Relagora)
        {
            Relagora.UmSegMais += new
           Relogio.IncrementacaoSeg(NovoSegPara1);
        }
        public void NovoSegPara1(object Relagora, InfHoras ta)
        {
            Console.WriteLine("Consumidor 1-->{0}:{1}:{2}{3}", ta.Hora,
           ta.Minuto, ta.Segundo, ta.Ciclos);
        }
    }
    public class Consumidor2
    {
        public void Subscricao(Relogio Relagora)
        {
            Relagora.UmSegMais += new
           Relogio.IncrementacaoSeg(NovoSegPara2);
        }
        public void NovoSegPara2(object Relagora, InfHoras ta)
        {
            Console.WriteLine("Consumidor 2-->{0}:{1}:{2}", ta.Hora,
           ta.Minuto, ta.Segundo);
        }
    }
    public class IncrementacaoDeSegundos
    {
        public static void Main()
        {
            Relogio Relagora = new Relogio();
            Consumidor1 C1 = new Consumidor1();
            C1.Subscricao(Relagora);
            Consumidor2 C2 = new Consumidor2();
            C2.Subscricao(Relagora);
            Relagora.Run();
        }
    }
}