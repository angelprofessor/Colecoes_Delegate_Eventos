﻿using System;
namespace DE11
{
    public class QuemLigou : EventArgs
    {
        private string Nome;
        private int Horas;
        public QuemLigou(string A, int H)
        {
            Nome = A;
            Horas = H;
        }
        public string DadosLigacao
        {
            get
            { return Nome + " telefonou às " + Horas; }
        }
    }
    public class Voicemail
    {
        private string PDesejada;
        public delegate void Telefonemas(object produtor, QuemLigou A);
        public event Telefonemas Ligou;
        public Voicemail(string P)
        { PDesejada = P; }
        public void VerificarOcorrencia(string A, int H)
        {
            if (A == PDesejada)
                Ligou(this, new QuemLigou(A, H));
        }
    }
    public class Email
    {
        public Email()
        { }
        public void subscricao(Voicemail C)
        { C.Ligou += new Voicemail.Telefonemas(Resposta); }
        public void Resposta(object VoiceMail, QuemLigou A)
        {
            Console.WriteLine("Recebi notificação: {0} e vou enviar email!", A.DadosLigacao);
        }
    }
    public class ControloVoiceMail
    {
        public static void Main()
        {
            string[] Nomes = { "Silva", "Paiva", "Ferreira", "Ferro", "Paiva", "Pinho", "Paiva" };
            int[] Horas = { 8, 12, 14, 17, 18, 19, 20 };
            Voicemail C = new Voicemail("Paiva");
            Email L = new Email();
            L.subscricao(C);
            for (int I = 0; I < Nomes.Length; I++)
            C.VerificarOcorrencia(Nomes[I], Horas[I]);
        }
    }
}