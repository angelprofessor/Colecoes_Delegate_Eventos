﻿using System;
using System.Collections;
namespace CC10
{
    public class RegistoFila
    {
        private string Nome;
        private int EntraServico;
        public RegistoFila(string N, int E){Nome = N;EntraServico = E;}
        public string PNome{get{ return Nome; }}
        public int PEntraServico{get{ return EntraServico; }}
    }
    public class FilaAoMinutoCerto
    {
        static void Main(string[] args)
        {
            Queue Q = new Queue();
            string[] Nomes = { "Carla", "Rui", "Rosa", "Abel", "Maria" };
            int[] Atendimento = { 10, 5, 7, 6, 12 };//TEMPO DE ATENDIMENTO
            ColocarNaFila(Q, Nomes, Atendimento);
            int TempoDecorrido = 0;
            FilaAoMinutoX(Q, TempoDecorrido);
        }
        public static void ColocarNaFila(Queue Q, string[] Nomes,int[] Atendimento)
        {
            int Entra = 0;
            for (int I = 0; I <= Nomes.GetLength(0) - 1; I++)
            {
                RegistoFila EleFila = new RegistoFila(Nomes[I], Entra);
                Entra += Atendimento[I];
                Q.Enqueue(EleFila);
            }
        }
        public static void FilaAoMinutoX(Queue Q, int TempoPassado)
        {
            //Console.Write("Minuto a que pretende entrar a fila ");
            int X = TempoPassado;// Convert.ToInt32(Console.ReadLine());
            RegistoFila EleFila;
            EleFila = (RegistoFila)Q.Peek();
            int Entra = EleFila.PEntraServico;
            while (X >= Entra)
            {
                Q.Dequeue();
                EleFila = (RegistoFila)Q.Peek();
                Entra = EleFila.PEntraServico;
            }
            Console.WriteLine("Estado da fila");
            IEnumerator ele = Q.GetEnumerator();
            while (ele.MoveNext())
            {
                EleFila = (RegistoFila)ele.Current;
                Console.WriteLine(EleFila.PNome + "--- Começa a ser atendido no minuto "+ EleFila.PEntraServico);}
                Console.WriteLine("Estão na fila {0} pessoas", Q.Count);
            }
        }
    }
