﻿using System;
using System.Collections;
namespace CC15
{
    public class Freguesia
    {
        private string Cod;
        private string Nome;
        public Freguesia(){
            Cod = "";
            Nome = "";
        }
        public Freguesia(string C, string Nf)
        {
            Cod = C;
            Nome = Nf;
        }
        public string PCod
        {
            get
            { return Cod; }
        }
        public string PNome
        {
            get
            { return Nome; }
        }
    }
    public class ListaDeFreguesias
    {
        static string[] Freguesia = new string[] { "Brás", "Móoca", "Itaquera", "ZZZ" };
        static string[] Codigo = new string[] { "BR", "MO", "IT", "ZZ" };

        static void Main(string[] args)
        {
            SortedList Lord = new SortedList();
            InserirFreguesias(Lord);
            ImprimirLista(Lord);
            ProcurarCodigos(Lord);
        }
        static void InserirFreguesias(SortedList Lord)
        {
            for(int  i=0;i< Freguesia.Length;i++)
            {
                Lord.Add(Freguesia[i], Codigo[i]);
            }


            //string CFreg, DFreg;
            //Freguesia F = new Freguesia();
            //Console.Write("Código da freguesia (ZZZ para terminar) ");
            //CFreg = Console.ReadLine();
            //while (CFreg.ToUpper().CompareTo("ZZZ") != 0)
            //{
            //    try
            //    {
            //        Console.Write("Nome da freguesia ");
            //        DFreg = Console.ReadLine();
            //        F = new Freguesia(CFreg, DFreg);
            //        Lord.Add(F.PCod, F.PNome);
            //    }
            //    catch
            //    {
            //        Console.WriteLine("Chave repetida. O último registo foiignorado."); 
            //    }
            //    Console.Write("Código da freguesia (ZZZ para terminar) ");
            //    CFreg = Console.ReadLine();
            //}
        }
    
        static void ImprimirLista(SortedList Lord)
        { string CFreg, DFreg; Console.WriteLine("{0}{1,10}", "Código", "Freguesia");
            for (int I = 0; I < Lord.Count; I++)
            {
                CFreg = (string)Lord.GetKey(I);
                DFreg = (string)Lord.GetByIndex(I);
                Console.WriteLine("{0} {1}", CFreg.PadRight(8), DFreg);
            }
        }
        static void ProcurarCodigos(SortedList Lord)
        {
            Console.Write("Código da freguesia a procurar (ZZZ para terminar) ");
            string CFreg = Console.ReadLine();
            while (CFreg.ToUpper().CompareTo("ZZZ") != 0)
            {
                if (Lord.ContainsKey(CFreg) == true)
                    Console.WriteLine("Índice de {0} registo de {1}",
                    Lord.IndexOfKey(CFreg), Lord[CFreg]);
                else
                    Console.WriteLine("{0} não existe na lista", CFreg);
                Console.Write("Código da freguesia a procurar (ZZZ para  terminar) ");
                CFreg = Console.ReadLine();
            }
        }
    }
}
