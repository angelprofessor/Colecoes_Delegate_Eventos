﻿using System;
namespace DE10
{
    public delegate void RespMultiplo5(object produtor, EventArgs arg);
    public class Produtor
    {
        public event RespMultiplo5 Multiplo5;
        public void GerarNumerosENotificar()
        {
            Random A = new Random(DateTime.Now.Millisecond);
            int Aleat;
            for (int I = 1; I <= 50; I++)
            {
                Aleat = A.Next() % 100;
                if (Aleat % 5 == 0)
                    Multiplo5(this, new EventArgs());
            }
        }
    }
    public class Consumidor
    {
        public static int M5 = 0;
        public void Subscricao(Produtor P)
        { P.Multiplo5 += new RespMultiplo5(RecebiUmMultiplo); }
        public void RecebiUmMultiplo(object produtor, EventArgs arg)
        {
            Console.WriteLine("Recebi um múltiplo de 5");
            M5++;
        }
    }
    public class RespostaAMultiplosDeCinco
    { 
        static void Main(string[] args)
        {
            Consumidor C = new Consumidor();
            Produtor P = new Produtor();
            C.Subscricao(P);
            P.GerarNumerosENotificar();
            Console.WriteLine("Recebi {0} múltiplos de 5",
            Consumidor.M5);
        }
    }
}