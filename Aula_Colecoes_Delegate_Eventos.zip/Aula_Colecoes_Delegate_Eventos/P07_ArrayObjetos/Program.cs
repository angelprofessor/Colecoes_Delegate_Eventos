﻿using System;
using System.Collections;
namespace CC7
{
    public class Usuario
    {
        private string Nome;
        private int AnoNasc;
        public Usuario(){Nome = "";AnoNasc = 0;}
        public Usuario(string N, int A){Nome = N;AnoNasc = A;}
        public string PNome{get{ return Nome; }}
        public int Idade(int AnoCorrente){ return AnoCorrente - AnoNasc; }
    }
    public class ListaDeObjetos
    {
        public static void Main()
        {
            ArrayList SPA = new ArrayList();
            Usuario UT = new Usuario();

            //CASO QUEIRA FAZER ENTRADA PELA TELA
            //Console.Write("Nome do Usuario (ZZZ para terminar) ");
            //int AnoUt = 0;
            //string NomeUt = Console.ReadLine();
            //while (NomeUt.ToUpper().CompareTo("ZZZ") != 0)
            //{
            //    Console.Write("Ano de nascimento do Usuario ");
            //    AnoUt = Convert.ToInt16(Console.ReadLine());
            //    UT = new Usuario(NomeUt, AnoUt);
            //    SPA.Add(UT);
            //    Console.Write("Nome do Usuario (ZZZ para terminar) ");
            //    NomeUt = Console.ReadLine();
            //}

            string[] Nomes = { "Carla", "Rui", "Beatriz", "Rosa", "Calorina", "Beto", "Abel", "Maria", "Dília", "ZZZ" };
            int[] Anos = { 2001, 1935, 2015, 2010, 1998, 1994, 2004, 2000, 2002, 0 };

            for(int i=0; i < Nomes.Length; i++)
            {
                UT = new Usuario(Nomes[i], Anos[i]);
                SPA.Add(UT);
            }

            Console.WriteLine("{0}{1,15}", "Usuario", "Idade");
            foreach (Usuario U in SPA)
                Console.WriteLine("{0} {1, 10}", U.PNome.PadRight(8),
                U.Idade(System.DateTime.Today.Year));
            Console.WriteLine("{0} Usuarios", SPA.Count);
        }
    }
}
