﻿using System;
using System.Collections;
namespace CC14
{
    public class AtualizacaoPaises
    {
        static string[] Paises = new string[] { "Brasil", "Espanha", "Portugal", "Bélgica", "Reino Unido", "Alemanha" };
        static string[] Capitais = new string[] { "Brasilia", "Madrid", "Lisboa", "Bruxelas", "Londres", "Berlim" };

        static void Main(string[] args)
        {
            Hashtable Ht = new Hashtable();
            InserirPaises(Ht);            
            Console.WriteLine("\n\n");
            Console.WriteLine("*********  ANTES DA REMOCAO ******");
            ImprimirPaises(Ht);
            RemoverPaises(Ht, "Alemanha");
            Console.WriteLine("\n\n");            
            Console.WriteLine("*********  APOS DA REMOCAO ******");
            ImprimirPaises(Ht);
        }
        public static void InserirPaises(Hashtable Ht)
        {
            //CASO QUEIRA ENTRADA MANUAL PELA TELA
            //string Capital, Pais;
            //Console.WriteLine("Inserção de países");
            //Console.Write("País a inserir (ZZZ para terminar) ");
            //Pais = Console.ReadLine();
            //while (Pais.ToUpper() != "ZZZ")
            //{
            //    try
            //    {
            //        Console.Write("Digite a capital ");
            //        Capital = Console.ReadLine();
            //        Ht.Add(Pais, Capital);
            //    }
            //    catch
            //    { Console.WriteLine("Chave repetida"); }
            //    Console.Write("País a inserir (ZZZ para terminar) ");
            //    Pais = Console.ReadLine();
            //}

            for (int i = 0; i < Paises.Length; i++)
            {
                Ht.Add(Paises[i], Capitais[i]);
            }

        }
        public static void RemoverPaises(Hashtable Ht, string Pais)
        {
            //string Pais;
            //Console.WriteLine("Remoção de países");
            //Console.Write("País a remover (ZZZ para terminar) ");
            //Pais = Console.ReadLine();
            //while (Pais.ToUpper() != "ZZZ" && Ht.Count > 0)
            //{
            //    Ht.Remove(Pais);
            //    Console.Write("País a remover (ZZZ para terminar) ");
            //    Pais = Console.ReadLine();
            //}

            Ht.Remove(Pais);
        }
        public static void ImprimirPaises(Hashtable Ht)
        {
            Console.WriteLine("Capitais registadas:");
            ICollection Chaves = Ht.Keys;
            foreach (string C in Chaves)
                Console.WriteLine("{0} --- {1}", C, Ht[C]);
        }
    }
}
