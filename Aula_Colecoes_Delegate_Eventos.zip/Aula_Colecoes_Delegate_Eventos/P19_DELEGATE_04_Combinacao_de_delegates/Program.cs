﻿using System;
namespace DE4
{
    delegate void DelegadoParaMensagens(string X);
    public class Mensagens
    {
        public static void Mensag1(string X)
        { Console.WriteLine(X + "do primeiro método"); }
        public static void Mensag2(string X)
        { Console.WriteLine(X + "do segundo método"); }
        public static void Mensag3(string X)
        { Console.WriteLine(X + "do terceiro método"); }
    }
    public class CombinacaoDeDelegados
    {
        static void Main(string[] args)
        {
            DelegadoParaMensagens[] R =
            {
                Mensagens.Mensag1,
                Mensagens.Mensag2, 
                Mensagens.Mensag3
            };
            DelegadoParaMensagens Sequencia;
            string X = "Primeira invocação ";
            Sequencia = R[0] + R[1];
            Sequencia(X);
            X = "Segunda invocação ";
            Sequencia += R[2];
            Sequencia(X);
        }
    }
}