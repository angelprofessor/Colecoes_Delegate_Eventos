﻿using System;
namespace DE2
{
    delegate int DelegadoParaExecFuncoes(int X);
    public class Multiplos
    {
        public static int Dobro(int X)
        { return X * 2; }
        public static int Triplo(int X)
        { return X * 3; }
        public static int Quadruplo(int X)
        { return X * 4; }
    }
    public class VectorDeFuncoes
    {
        static void Main(string[] args)
        {
            int X = 5;
            int Total = 0; 
            DelegadoParaExecFuncoes[] D = {Multiplos.Dobro,
            Multiplos.Triplo, Multiplos.Quadruplo};
            for (int I = 0; I < D.Length; I++)
                Total += D[I](X);

            Console.WriteLine(
                "Somatório do dobro, triplo e quadrúplo de {0}={1}",
                X, Total);            
        }
    }
}