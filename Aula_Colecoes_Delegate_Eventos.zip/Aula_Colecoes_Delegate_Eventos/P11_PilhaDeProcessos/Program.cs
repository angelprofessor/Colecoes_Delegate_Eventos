﻿using System;
using System.Collections;
namespace CC11
{
    public class PilhaDeProcessos
    {
        static void Main(string[] args)
        {
            Stack Pilha = new Stack();
            Empilhar(Pilha);
            OrdemResolucao(Pilha);
        }
        public static void Empilhar(Stack Pilha)
        {
            //CASO QUEIRA FAZER ENTRADA MANUAL PELA TELA
            //string Codigo;
            //Console.Write("Código do processo(ZZZ para terminar) ");
            //Codigo = Console.ReadLine();
            //while (Codigo.ToUpper() != "ZZZ")
            //{
            //    Pilha.Push(Codigo);
            //    Console.Write("Código do processo(ZZZ para terminar) ");
            //    Codigo = Console.ReadLine();
            //}

            string[] Codigos = new string[]{"A", "B","C", "D", "A", "B", "C", "D" };
            foreach(string cod in Codigos)
            {
                Pilha.Push(cod);
            }

        }
        public static void OrdemResolucao(Stack Pilha)
        {
            Console.WriteLine("Ordem de resolução dos processos:");
            while (Pilha.Count > 0)
            {
                Console.WriteLine(Pilha.Peek());
                Pilha.Pop();
            }
        }
    }
}