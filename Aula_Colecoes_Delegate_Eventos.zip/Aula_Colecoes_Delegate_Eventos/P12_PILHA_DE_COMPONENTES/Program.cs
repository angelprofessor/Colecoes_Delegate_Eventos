﻿using System;
using System.Collections;
namespace CC12
{
    public class Componentes
    {
        private int Cod;
        private int TempoP;
        public Componentes(int C, int T)
        {
            Cod = C;
            TempoP = T;
        }
        public int Pcod
        {
            get
            { return Cod; }
        }
        public int PTempoP
        {
            get
            { return TempoP; }
        }
    }
    public class PilhaDeComponentes
    {
        static void Main(string[] args)
        {
            Stack S1 = new Stack();
            Stack S2 = new Stack();
            int[,] Subcomp ={{1,10},{2,15},{3,5},{4,15},{5,10},{6,15},{7,30},{8,12}};
            EmpilharSingular(Subcomp, S1);
            EmpilharComposta(S1, S2);
            ImprimirComposta(S2);
        }
        public static void EmpilharSingular(int[,] Subcomp, Stack S1)
        {
            for (int i = 0; i <= Subcomp.GetLength(0) - 1; i++)
            {
                Componentes C1 = new Componentes(Subcomp[i, 0], Subcomp[i, 1]);
                S1.Push(C1);
            }
        }
        public static void EmpilharComposta(Stack S1, Stack S2)
        {
            Componentes NovaComponente, C1, C2;
            while (S1.Count > 0)
            {
                C1 = (Componentes)S1.Pop();
                try
                {
                    C2 = (Componentes)S1.Pop();
                    NovaComponente = new Componentes(C1.Pcod + C2.Pcod, C1.PTempoP
                    + C2.PTempoP);
                }
                catch
                { NovaComponente = new Componentes(C1.Pcod, C1.PTempoP); }
                S2.Push(NovaComponente);
            }
        }
        public static void ImprimirComposta(Stack S2)
        {
            Componentes NovaComponente;
            IEnumerator ele = S2.GetEnumerator();
            while (ele.MoveNext())
            {
                NovaComponente = (Componentes)ele.Current;
                Console.WriteLine("{0} é processada em {1} segundos",
                NovaComponente.Pcod, NovaComponente.PTempoP);
            }
        }
    }
}