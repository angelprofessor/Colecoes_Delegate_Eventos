﻿using System;
using System.Collections;
namespace CC13
{
    public class CapitaisEuropeias
    {
        static string[] Paises = new string[] { "Brasil", "Espanha", "Portugal","Bélgica", "Reino Unido",  "Alemanha" };
        static string[] Capitais = new string[] { "Brasilia", "Madrid", "Lisboa", "Bruxelas", "Londres", "Berlim" };
        static void Main(string[] args)
        {
            Hashtable Ht = new Hashtable();
            InserirRegistos(Ht);
            ProcurarCapitais(Ht);
        }
        static void InserirRegistos(Hashtable Ht)
        {
            //CASO QUEIRA ENTRADA MANUAL PELA TELA
            //string Capital;
            //Console.Write("Digite o país (ZZZ para terminar) ");
            //string Pais = Console.ReadLine();
            //while (Pais.ToUpper() != "ZZZ")
            //{
            //    Console.Write("Digite a capital ");
            //    Capital = Console.ReadLine();
            //    Ht.Add(Pais, Capital);
            //    Console.Write("Digite o país (ZZZ para terminar) ");
            //    Pais = Console.ReadLine();
            //}

            for(int i=0;i<Paises.Length;i++)
            {
                Ht.Add(Paises[i], Capitais[i]);
            }

        }
        static void ProcurarCapitais(Hashtable Ht)
        {
            //CASO QUEIRA FAZER O  EXERCICIOS POR ENTRADA MANUAL
            //Console.WriteLine("Capitais:");
            //Console.Write("Digite o país cuja capital procura (ZZZ paraterminar) ");
            //string Aprocurar =  Console.ReadLine();
            //do
            //{
            //    if (Ht[Aprocurar] != null) 
            //        Console.WriteLine("{0} --- {1}", Aprocurar, Ht[Aprocurar]);
            //    else
            //        Console.WriteLine("{0} não foi registado.", Aprocurar);
            //    Console.Write("Digite o país cuja capital procura (ZZZ para terminar) ");
            //    Aprocurar = Console.ReadLine();
            //}
            //while (Aprocurar.ToUpper() != "ZZZ");

            Console.WriteLine("Lista de Paizes Cadastrados");
            foreach (string pais  in Paises)
            {
                Console.WriteLine("{0} --- {1}", pais, Ht[pais]);
            }
        }
    }
}
