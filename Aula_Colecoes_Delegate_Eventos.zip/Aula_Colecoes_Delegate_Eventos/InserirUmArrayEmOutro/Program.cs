﻿using System;
using System.Collections;
namespace CC5
{
    public class InsercaoLista
    {
        public static void Main()
        {
            ArrayList Frutos = new ArrayList();
            ArrayList FrutosTropicais = new ArrayList();
            string[] F = { "Maçã", "Laranja", "Pêra", "Cereja", "Tangerina" };
            string[] FT = { "Banana", "Papaia", "Anona", "Manga" };
            foreach (string Ele in F)
                Frutos.Add(Ele);
            foreach (string Ele in FT)
                FrutosTropicais.Add(Ele);
            Frutos.InsertRange(Frutos.Count, FrutosTropicais);
            Frutos.Sort();
            foreach (string Ele in Frutos)
                Console.WriteLine("{0}", Ele);
            Console.WriteLine("{0} espécies de frutos", Frutos.Count);
        }
    }
}
