﻿using System;
namespace DE9
{
    public class ParDeObjectos
    {
        private object[] OPar = new object[2];
        public delegate int Ordenar(object O1, object O2);
        public ParDeObjectos(object O1, object O2)
        {
            OPar[0] = O1;
            OPar[1] = O2;
        }
        public void Ordem(Ordenar FuncaoDel)
        {
            if (FuncaoDel(OPar[0], OPar[1]) == 2)
            {
                object Temporaria = OPar[0];
                OPar[0] = OPar[1];
                OPar[1] = Temporaria;
            }
        }
        public override string ToString()
        { return OPar[0].ToString() + " e " + OPar[1].ToString(); }
    }
    public class Pessoa
    { public string Nome; public Pessoa(string N)
        { Nome = N; }
        public static int OrdemNomes(Object O1, object O2)
        {
            Pessoa P1 = (Pessoa)O1;
            Pessoa P2 = (Pessoa)O2;
            return (String.Compare(P1.Nome, P2.Nome) < 0 ? 1 : 2);
        }
        public override string ToString()
        { return Nome; }
    }
    public class OrdenarNomes
    {
        static void Main(string[] args)
        {
            Pessoa P1 = new Pessoa("Joana");
            Pessoa P2 = new Pessoa("Abel");
            ParDeObjectos Pares = new ParDeObjectos(P1, P2);
            ParDeObjectos.Ordenar Delegado = new
            ParDeObjectos.Ordenar(Pessoa.OrdemNomes);
            Pares.Ordem(Delegado);
            Console.WriteLine(Pares.ToString());
        }
    }
}